//
//  main.m
//  SSZipArchive
//
//  Created by Sam Soffes on 9/7/13.
//  Copyright (c) 2013-2014 Sam Soffes. All rights reserved.
//

#import "SSAppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
		return UIApplicationMain(argc, argv, nil, NSStringFromClass([SSAppDelegate class]));
	}
}
